<p align="center">
  <img src="https://i.imgur.com/eTPe4pz.png" width="154">
  <h1 align="center">INSSIST Pro | Instagram Web Assistant</h1>
  <p align="center">Inssist allows you to use most of <b>Instagram</b> features on your PC.</p>
   <p align="center">
   <img src="https://img.shields.io/github/downloads/YezerSTN/INSSIST/total?color=red&label=DOWNLOADS">
   <img src="https://img.shields.io/github/v/tag/YezerSTN/INSSIST?label=VERSION">
   <img src="https://img.shields.io/github/stars/YezerSTN/INSSIST?style=social">	
   </p>
   
 > <p align="center">ᵔᵔ﹗ ﹙𝐼 𝑙𝑜𝑣𝑒 𝑡𝑜 𝑔𝑒𝑡 𝑚𝑦 ℎ𝑜𝑝𝑒𝑠 𝑢𝑝﹚<p>
		
**Version:** This version of INSSIST has all the options offered by the <b>PRO</b> version. 
	
**Rationale:** This is all done for profit and so that you can use the full potential of this tool.
<br />

# INSSIST Features
**Cracked Features**
- Post Reels
- Video Stories
- Add Music to Videos
- Ghost Story View
- Post and Schedule Carousels
- Schedule and Bulk Draft Posts
- Posting Calendar
- Posting Time Slots
- CSV-powered Scheduling
- Custom Video Covers
- Cross-posting to Facebook Pages
- Hashtags Metrics & Collections


<br />


## How to Use

**STEP 1** Using this extension is easy, just go to [releases](https://github.com/YezerSTN/INSSIST/releases) and download the latest version. 

**STEP 2** Once you have downloaded the RAR you have to unzip it.

**STEP 3** Go to [ chrome://extensions/ ] and enable developer mode.

<p align="center">
	<img src="https://topesdegama.com/app/uploads-topesdegama.com/2018/06/Modo-desarrallador-Chrome.jpg" alt="InstaPy reach" width="650px"/>
</p>

**STEP 4** Once the developer mode is enabled, now just load the unzipped folder. And that's it, you can use it now.

<p align="center">
	<img src="https://topesdegama.com/app/uploads/2018/06/Opciones-desarrollador-Chorme.jpg" alt="InstaPy reach" width="650px"/>
</p>

## Credits 	
### Yezer
I am Christian Yezer and I have made this repository to publish future versions of INSSIST with PRO functions. I hope you like my contribution, regards. ♡

<p align="center">
	<img src="https://i.pinimg.com/564x/8c/f7/2d/8cf72dbbf7f4f5c0a36c0e3608664088.jpg" alt="InstaPy reach" width="600px"/>
</p>

### Contact us

  <p align="center">
    <a href="https://www.instagram.com/yezer._/">
      <img src="https://i.imgur.com/BThmrhA.png" alt="Insta reach" width="75px" />
    </a>
    <a href="https://www.youtube.com/c/Yezer/videos">
      <img src="https://i.imgur.com/utgFsnv.png" alt="Insta reach" width="75px" />
    </a>
  </p>
</p>

---

> **Disclaimer**<a name="disclaimer" />: Please note that this is a research project. I am in no way responsible for the use of this tool. 
